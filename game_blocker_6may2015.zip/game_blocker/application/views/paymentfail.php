<article class="loginpanel clearfix">
	<h2>Payment Failure</h2>
	<div class="clear"></div>
	<span class="right"><a href="<?php echo base_url(); ?>/tournament">Back to tournament</a></span>
	<div class="clear"></div>
</article>