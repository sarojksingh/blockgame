
        <!-- login panel   -->
        <div class="game_zone">
        	<aside id="left_players">
            	<div class="player_one">
                	<p class="player_img"></p>
                    <span class="player_name">JESSICA</span>
                    <span class="player_win_points">WINS: 5</span>
                </div>
                <div class="player_two">
                	<p class="player_img"></p>
                    <span class="player_name">MARK</span>
                    <span class="player_win_points">WINS: 2</span>
                </div>
            </aside>
            <div class="game_canvas"></div>
            <aside id="right_players">
            	<div class="player_three">
                	<p class="player_img"></p>
                    <span class="player_name">SIMONE</span>
                    <span class="player_win_points">WINS: 7</span>
                </div>
                <div class="player_four">
                	<p class="player_img"></p>
                    <span class="player_name">JAMES</span>
                    <span class="player_win_points">WINS: 1</span>
                </div>
            </aside>
        </div>
