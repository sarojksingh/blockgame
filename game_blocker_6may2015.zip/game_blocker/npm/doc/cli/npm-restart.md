npm-restart(1) -- Start a package
=================================

## SYNOPSIS

    npm restart [-- <args>]

## DESCRIPTION

This runs a package's "restart" script, if one was provided.  Otherwise it runs
package's "stop" script, if one was provided, and then the "start" script.

## SEE ALSO

* npm-run-script(1)
* npm-scripts(7)
* npm-test(1)
* npm-start(1)
* npm-stop(1)
